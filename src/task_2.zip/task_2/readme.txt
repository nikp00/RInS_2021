V resnici je hw6, task_2 je ime samo zaradi tega ker smo združili skupaj vse.
